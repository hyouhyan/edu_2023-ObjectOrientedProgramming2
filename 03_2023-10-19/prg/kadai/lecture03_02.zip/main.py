#!/usr/bin/env python
# -*- coding: utf-8 -*-

from my_module import Hero, Magician2

hero = Hero(name="愛知太郎", hp=1000)
print(hero)
magician = Magician2(name="愛知次郎", hp=200, mp=100)
print(magician)