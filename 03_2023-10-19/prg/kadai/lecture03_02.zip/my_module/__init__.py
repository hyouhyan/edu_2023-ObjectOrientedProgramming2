from .K22047.lecture03_hero import Hero
from .K22047.lecture03_magician2 import Magician2